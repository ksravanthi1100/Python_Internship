# Stock Portfolio Tracker

# Dictionary containing stock prices
stock_prices = {
    "TCS": 3500,
    "INFY": 1800,
    "RELIANCE": 2500,
    "HDFC": 1700,
    "WIPRO": 450
}

portfolio = {}

# Ask the user how many different stocks they own
n = int(input("Enter the number of different stocks: "))

# Get stock details from the user
for i in range(n):
    stock = input("Enter stock name: ").upper()

    if stock in stock_prices:
        quantity = int(input("Enter quantity: "))
        portfolio[stock] = quantity
    else:
        print("Stock not found!")

# Calculate total investment
total = 0

print("\n----- Portfolio Summary -----")

for stock, quantity in portfolio.items():
    value = stock_prices[stock] * quantity
    total += value
    print(stock, ":", quantity, "shares =", value)

print("-----------------------------")
print("Total Investment Value =", total)