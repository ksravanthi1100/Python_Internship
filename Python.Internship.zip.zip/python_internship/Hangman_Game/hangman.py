import random

words = ["python", "apple", "laptop", "school", "flower"]

word = random.choice(words)
guessed = []
attempts = 6

print("===== HANGMAN GAME =====")

while attempts > 0:
    display = ""

    for letter in word:
        if letter in guessed:
            display += letter + " "
        else:
            display += "_ "

    print("\nWord:", display)

    if "_" not in display:
        print("\n🎉 Congratulations! You guessed the word:", word)
        break

    guess = input("Enter a letter: ").lower()

    if guess in guessed:
        print("You already guessed that letter.")
        continue

    guessed.append(guess)

    if guess not in word:
        attempts -= 1
        print("Wrong guess!")
        print("Remaining attempts:", attempts)

if attempts == 0:
    print("\nGame Over!")
    print("The word was:", word)
